<?php
if(!@include_once("lib/compat/index.php")) throw new Exception("Compat: Compatibility is missing. Failed to include Compatibility");
?>