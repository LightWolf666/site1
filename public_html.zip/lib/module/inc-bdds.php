<div class="drives-con-container">
	<div class="container-tx3-block darkmode-txt">
		<div class="anchor-point" id="compatible_bdd_lg">
		</div>
		<div class='container-emp-block'>
		</div>
		<span>
		LG Drives </span>
	</div>
	<div class="drives-con-divider darkmode-divider">
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BE16NU50 <span class="drives-txt-revisions">External Drive</span></span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BH14NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BH16NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BH16NS48</span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BH16NS55</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BH26NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BP50NB40 <span class="drives-txt-revisions">External Drive</span></span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BU20N</span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BU40N</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>CH12NS30</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>UH12NS30</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH12LS30 <span class="drives-txt-revisions">Some revisions</span></span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH14NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH16NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH16NS48</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH24LS30</span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH24NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WH26NS40</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BH16NS60</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BE14NU40</span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>WP50NB40</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
	</div>
</div>
<div class="drives-con-container">
	<div class="container-tx3-block darkmode-txt">
		<div class="anchor-point" id="compatible_bdd_asus">
		</div>
		<div class='container-emp-block'>
		</div>
		<span>
		ASUS Drives </span>
	</div>
	<div class="drives-con-divider darkmode-divider">
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BC-08B1LT</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BC-12B1ST <span class="drives-txt-revisions">Some revisions</span></span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BC-12D2HT</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BC-16D1HT</span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BW-12B1ST</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BW-16D1HT</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
	</div>
	<div class="drives-con-outer darkmode-txt" style="display:none">
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
	</div>
</div>
<div class="drives-con-container">
	<div class="container-tx3-block darkmode-txt">
		<div class="anchor-point" id="compatible_bdd_samsung">
		</div>
		<div class='container-emp-block'>
		</div>
		<span>Samsung Drives </span>
	</div>
	<div class="drives-con-divider darkmode-divider">
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>SH-B083L</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>SH-B123L</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>SE-506</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>SE-406</span>
		</div>
	</div>
</div>
<div class="drives-con-container">
	<div class="container-tx3-block darkmode-txt">
		<div class="anchor-point" id="compatible_bdd_lite_on">
		</div>
		<div class='container-emp-block'>
		</div>
		<span>LITE-ON Drives </span>
	</div>
	<div class="drives-con-divider darkmode-divider">
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>DH-4O1S</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>IHBS112</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>IHBS312</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>DS-6E2SH <span class="drives-txt-revisions">19C revision</span></span>
		</div>
	</div>
</div>
<div class="drives-con-container">
	<div class="container-tx3-block darkmode-txt">
		<div class="anchor-point" id="compatible_bdd_sony">
		</div>
		<div class='container-emp-block'>
		</div>
		<span>Sony Drives </span>
	</div>
	<div class="drives-con-divider darkmode-divider">
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>Optiarc 5300S</span>
		</div>
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>PlayStation 3 BDD<span class="drives-txt-revisions">With proprietary adapter</span></span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
	</div>
</div>
<div class="drives-con-container">
	<div class="container-tx3-block darkmode-txt">
		<div class="anchor-point" id="compatible_bdd_benq">
		</div>
		<div class='container-emp-block'>
		</div>
		<span>
		BenQ Drives </span>
	</div>
	<div class="drives-con-divider darkmode-divider">
	</div>
	<div class="drives-con-outer darkmode-txt">
		<div class="drives-con-inner darkmode-txt">
			<div class="drives-ico-bluray darkmode-invert">
			</div>
			<span>BR1000</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
		<div class="drives-con-inner drives-txt-hidden">
			<span>XX-XXXXXX</span>
		</div>
	</div>
</div>
